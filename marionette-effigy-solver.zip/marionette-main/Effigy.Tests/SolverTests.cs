using System;
using Effigy;
using static Effigy.Tests.Report;

namespace Effigy.Tests;

public static class SolverTests
{
	public static void Run()
	{
		Section( "sketch solver: empty and trivial" );
		TestEmpty();
		TestNoConstraints();

		Section( "sketch solver: distance" );
		TestDistance();
		TestDistanceAlreadySatisfied();

		Section( "sketch solver: horizontal / vertical" );
		TestHorizontalVertical();
		TestRectangleHV();

		Section( "sketch solver: coincident" );
		TestCoincident();

		Section( "sketch solver: equal length / parallel / perpendicular" );
		TestEqualLength();
		TestParallel();
		TestPerpendicular();

		Section( "sketch solver: multi-constraint square" );
		TestSquareDistances();
	}

	static void TestEmpty()
	{
		var s = new Sketch();
		var r = SketchSolver.Solve( s );
		Check( "empty sketch converges", r.Converged, $"converged={r.Converged}" );
	}

	static void TestNoConstraints()
	{
		var s = new Sketch();
		s.AddPoint( 0, 0 );
		s.AddPoint( 3, 4 );
		var r = SketchSolver.Solve( s );
		Check( "no constraints leaves points alone", r.Converged
			&& Near( s.Points[1], new Vec2( 3, 4 ), 1e-5f ),
			$"p1={s.Points[1]}" );
	}

	static void TestDistance()
	{
		var s = new Sketch();
		s.AddPoint( 0, 0 ); // pinned
		s.AddPoint( 1, 1 );
		s.AddConstraint( SketchConstraintKind.Distance, 0, 1, 1f );

		var r = SketchSolver.Solve( s );
		var d = Dist( s.Points[0], s.Points[1] );
		Check( "distance constrains a segment", r.Converged && Near( d, 1f, 1e-4f ),
			$"converged={r.Converged} residual={r.Residual:0.####e0} d={d:0.####} p1={s.Points[1]}" );
	}

	static void TestDistanceAlreadySatisfied()
	{
		var s = new Sketch();
		s.AddPoint( 0, 0 );
		s.AddPoint( 1, 0 );
		s.AddConstraint( SketchConstraintKind.Distance, 0, 1, 1f );
		var r = SketchSolver.Solve( s );
		Check( "already-satisfied distance stays put", r.Converged
			&& Near( s.Points[1], new Vec2( 1, 0 ), 1e-4f ),
			$"p1={s.Points[1]} residual={r.Residual:0.####e0}" );
	}

	static void TestHorizontalVertical()
	{
		var s = new Sketch();
		s.AddPoint( 0, 0 );
		s.AddPoint( 2, 1.5f );
		s.AddConstraint( SketchConstraintKind.Horizontal, 0, 1 );
		var r = SketchSolver.Solve( s );
		Check( "horizontal forces equal y", r.Converged
			&& Near( s.Points[0].y, s.Points[1].y, 1e-4f ),
			$"y0={s.Points[0].y} y1={s.Points[1].y} residual={r.Residual:0.####e0}" );

		s = new Sketch();
		s.AddPoint( 0, 0 );
		s.AddPoint( 1.5f, 3 );
		s.AddConstraint( SketchConstraintKind.Vertical, 0, 1 );
		r = SketchSolver.Solve( s );
		Check( "vertical forces equal x", r.Converged
			&& Near( s.Points[0].x, s.Points[1].x, 1e-4f ),
			$"x0={s.Points[0].x} x1={s.Points[1].x}" );
	}

	static void TestRectangleHV()
	{
		// Four corners of a skewed quad; H/V on each edge → axis-aligned rectangle.
		var s = new Sketch();
		var p0 = s.AddPoint( 0, 0 );
		var p1 = s.AddPoint( 3, 0.4f );
		var p2 = s.AddPoint( 2.6f, 2.2f );
		var p3 = s.AddPoint( -0.3f, 1.8f );
		s.AddConstraint( SketchConstraintKind.Horizontal, p0, p1 );
		s.AddConstraint( SketchConstraintKind.Vertical, p1, p2 );
		s.AddConstraint( SketchConstraintKind.Horizontal, p2, p3 );
		s.AddConstraint( SketchConstraintKind.Vertical, p3, p0 );

		var r = SketchSolver.Solve( s );
		Check( "H/V rectangle converges", r.Converged,
			$"converged={r.Converged} residual={r.Residual:0.####e0} iters={r.Iterations}" );
		Check( "bottom edge horizontal", Near( s.Points[p0].y, s.Points[p1].y, 1e-3f ),
			$"y0={s.Points[p0].y} y1={s.Points[p1].y}" );
		Check( "right edge vertical", Near( s.Points[p1].x, s.Points[p2].x, 1e-3f ),
			$"x1={s.Points[p1].x} x2={s.Points[p2].x}" );
	}

	static void TestCoincident()
	{
		var s = new Sketch();
		s.AddPoint( 0, 0 );
		s.AddPoint( 2, 3 );
		s.AddConstraint( SketchConstraintKind.Coincident, 0, 1 );
		var r = SketchSolver.Solve( s );
		Check( "coincident collapses points", r.Converged
			&& Near( s.Points[0], s.Points[1], 1e-4f ),
			$"p0={s.Points[0]} p1={s.Points[1]} residual={r.Residual:0.####e0}" );
	}

	static void TestEqualLength()
	{
		var s = new Sketch();
		var a0 = s.AddPoint( 0, 0 );
		var a1 = s.AddPoint( 2, 0 );
		var b0 = s.AddPoint( 0, 1 );
		var b1 = s.AddPoint( 0.5f, 1 );
		s.AddConstraint( SketchConstraintKind.EqualLength, a0, a1, b0, b1 );
		var r = SketchSolver.Solve( s );
		var da = Dist( s.Points[a0], s.Points[a1] );
		var db = Dist( s.Points[b0], s.Points[b1] );
		Check( "equal length matches segment lengths", r.Converged && Near( da, db, 1e-3f ),
			$"da={da:0.####} db={db:0.####} residual={r.Residual:0.####e0}" );
	}

	static void TestParallel()
	{
		var s = new Sketch();
		var a0 = s.AddPoint( 0, 0 );
		var a1 = s.AddPoint( 2, 0 );
		var b0 = s.AddPoint( 0, 1 );
		var b1 = s.AddPoint( 1.5f, 1.8f );
		s.AddConstraint( SketchConstraintKind.Parallel, a0, a1, b0, b1 );
		var r = SketchSolver.Solve( s );
		var ux = s.Points[a1].x - s.Points[a0].x;
		var uy = s.Points[a1].y - s.Points[a0].y;
		var vx = s.Points[b1].x - s.Points[b0].x;
		var vy = s.Points[b1].y - s.Points[b0].y;
		var cross = MathF.Abs( ux * vy - uy * vx );
		Check( "parallel drives cross product to zero", r.Converged && cross < 1e-3f,
			$"cross={cross:0.####e0} residual={r.Residual:0.####e0}" );
	}

	static void TestPerpendicular()
	{
		var s = new Sketch();
		var a0 = s.AddPoint( 0, 0 );
		var a1 = s.AddPoint( 2, 0 );
		var b0 = s.AddPoint( 1, 0 );
		var b1 = s.AddPoint( 2, 1.5f );
		s.AddConstraint( SketchConstraintKind.Perpendicular, a0, a1, b0, b1 );
		var r = SketchSolver.Solve( s );
		var ux = s.Points[a1].x - s.Points[a0].x;
		var uy = s.Points[a1].y - s.Points[a0].y;
		var vx = s.Points[b1].x - s.Points[b0].x;
		var vy = s.Points[b1].y - s.Points[b0].y;
		var dot = MathF.Abs( ux * vx + uy * vy );
		Check( "perpendicular drives dot product to zero", r.Converged && dot < 1e-3f,
			$"dot={dot:0.####e0} residual={r.Residual:0.####e0}" );
	}

	static void TestSquareDistances()
	{
		// Point 0 fixed at origin. Three free corners of a unit square, constrained by side lengths
		// and one diagonal so the shape is determined.
		var s = new Sketch();
		var p0 = s.AddPoint( 0, 0 );
		var p1 = s.AddPoint( 1.2f, 0.1f );
		var p2 = s.AddPoint( 1.1f, 1.3f );
		var p3 = s.AddPoint( -0.1f, 0.9f );
		s.AddConstraint( SketchConstraintKind.Distance, p0, p1, 1f );
		s.AddConstraint( SketchConstraintKind.Distance, p1, p2, 1f );
		s.AddConstraint( SketchConstraintKind.Distance, p2, p3, 1f );
		s.AddConstraint( SketchConstraintKind.Distance, p3, p0, 1f );
		s.AddConstraint( SketchConstraintKind.Distance, p0, p2, MathF.Sqrt( 2f ) ); // diagonal

		var r = SketchSolver.Solve( s );
		Check( "unit square with diagonal converges", r.Converged,
			$"converged={r.Converged} residual={r.Residual:0.####e0} iters={r.Iterations}" );
		Check( "side 0-1 length 1", Near( Dist( s.Points[p0], s.Points[p1] ), 1f, 1e-3f ),
			$"d={Dist( s.Points[p0], s.Points[p1] ):0.####}" );
		Check( "side 1-2 length 1", Near( Dist( s.Points[p1], s.Points[p2] ), 1f, 1e-3f ),
			$"d={Dist( s.Points[p1], s.Points[p2] ):0.####}" );
		Check( "diagonal 0-2 is √2", Near( Dist( s.Points[p0], s.Points[p2] ), MathF.Sqrt( 2f ), 1e-3f ),
			$"d={Dist( s.Points[p0], s.Points[p2] ):0.####}" );
	}

	static float Dist( Vec2 a, Vec2 b )
	{
		var dx = a.x - b.x;
		var dy = a.y - b.y;
		return MathF.Sqrt( dx * dx + dy * dy );
	}

	static bool Near( float a, float b, float eps ) => MathF.Abs( a - b ) <= eps;
	static bool Near( Vec2 a, Vec2 b, float eps ) =>
		MathF.Abs( a.x - b.x ) <= eps && MathF.Abs( a.y - b.y ) <= eps;
}
